from django.apps import AppConfig


class CovidappConfig(AppConfig):
    name = 'covidapp'
